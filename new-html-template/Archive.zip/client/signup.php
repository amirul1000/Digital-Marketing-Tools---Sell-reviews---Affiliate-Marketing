<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <meta
      name="title"
      content="CAB ACCESS Transport handicapé et de personne âgée"
    />
    <meta
      name="description"
      content="Le spécialiste du transport de personnes à mobilité réduite, Transport de personnes handicapées et Transport de personne âgées."
    />
    <meta
      name="keywords"
      content="tpmr; pmr transport; transport pmr;
                transport handicapé;
                transport handicapés;
                handicapé transport;
                transport handicape;
                transport handicap;
                transport mobilité réduite;
                transport adapté;
                transports handicapés;
                transport des handicapés;
                transport enfant handicapé;
                transports handicapés;
                transport personne agée;
                taxi handicapé;
                handicapé taxi;
                taxi pmr;
                taxi avec rampe;
                transport handicapes;
                transport de personnes handicapées;
                transport de personne handicapé;
                transport personnes âgées;
                transport personnes handicapées;
                transport de personnes à mobilité réduite;
                transport personne mobilité réduite;
                transport de personnes agées;
                transport personnes agée;
                transport personnes handicapées;
                transport personne handicapée;
                transport personne agée;"
    />
    <link rel="icon" type="image/png" href="../assets/images/DigitalsLogoWhite.png" />

    <title>Sign Up</title>

    <link href="../assets/css/bootstrap-grid.css" rel="stylesheet" />
    <!-- <link href="assets/css/font-awesome.min.css" rel="stylesheet" /> -->
    <link
      rel="stylesheet"
      href="../assets/webfont/fontawesome-free-6.1.1-web/css/all.css"
    />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/css/swiper.css" rel="stylesheet" />
    <link href="../assets/css/swipebox.css" rel="stylesheet" />
    <link href="../assets/css/zoomslider.css" rel="stylesheet" />
    <link href="../assets/css/customStyle.css" rel="stylesheet" />
    <link
      rel="stylesheet"
      href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css"
    />

    <link
      href="https://fonts.googleapis.com/css?family=Fira+Sans+Condensed:700,800%7COpen+Sans:400,600,700"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
      integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
      crossorigin="anonymous"
    />

    <script
      src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
      integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
      integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
      integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
      crossorigin="anonymous"
    ></script>

    <script
      type="text/javascript"
      src="../assets/js/modernizr-2.6.2.min.js"
    ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.js"></script>

  <script>
    $(document).ready(function() {
      $("#signUpForm").validate();
    });
  </script>
  </head>
  <body class="signInBody">
    <style>
      ::-webkit-scrollbar {
        display: none;
      }
    </style>
    <main>
      <div class="wrapperLeft">
        <div class="left blueGradient">
          <img
            width="250px"
            class="signInLogo"
            src="../assets/images/logo (1) (1).png"
            alt=""
            srcset=""
          />
          <p class="signInText">TOP REVIEWS IS THE N1 REVIEWS AGENCY

          </p>
          <h1 class="signInHeading" style="margin-bottom: 100px;">Buy Reviews To Get Customers Trust and More Sales </h1>
          <div
          id="carouselExampleIndicators"
          class="carousel slide"
          data-ride="carousel"
          style="margin-bottom: 20px;"
        >
          <ol class="carousel-indicators" style="margin: -20px auto;"
          >
            <li
              data-target="#carouselExampleIndicators"
              data-slide-to="0"
              class="c_indicator active"
            ></li>
            <li
              data-target="#carouselExampleIndicators"
              data-slide-to="1"
              class="c_indicator"
            ></li>
            <li
              data-target="#carouselExampleIndicators"
              data-slide-to="2"
              class="c_indicator"
            ></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="left">
                <img
                  width="130px"
                  class="signInImg"
                  src="../assets/images/person1.png"
                  alt=""
                />
                <span class="signInAvatarTitle">Mollie Steele</span>
                <!-- <h3>Managing director of school transport company</h3> -->
                <p class="signInQuote">
                  “
                  This Buy Real Media website really got my coffee shop really popular on local searches!! Best tool ever. Before this, I didn't even have my store on Google Maps.  Thank you”
                </p>
                <!-- <p>Merci Digital Office -->

              </div>
            </div>
            <div class="carousel-item">
              <div class="left">
                <img
                  width="130px"
                  class="signInImg"
                  src="../assets/images/person2.png"
                  alt=""
                />
                <span class="signInAvatarTitle">Sofia Chan</span>
                <!-- <h3>Managing director of school transport company</h3> -->
                <p class="signInQuote">
                  “
                  I have a jewelry shop and it was very important for me to have a good score. So I bought Google reviews from this website, and now I can't even place to fit my customers into my schedule. You guys deserve much more! Thanks!                    ”
                </p>
                <!-- <p>Merci Digital Office</p> -->

              </div>
            </div>
            <div class="carousel-item">
              <div class="left" style="background: transparent !important;">
                <img
                  width="130px"
                  class="signInImg"
                  src="../assets/images/person3.png"
                  alt=""
                />
                <span class="signInAvatarTitle">Isabell Short</span>
                <!-- <h3>Managing director of school transport company</h3> -->
                <p class="signInQuote">
                  “
                  The Google my business reviews have been coming quickly and I have been able to see the results in a short time. So I can say that it is a quality service.                    ”
                </p>
                <!-- <p>Merci Digital Office</p> -->

              </div>
            </div>
            <div class="carousel-item">
              <div class="left" style="background: transparent !important;">
                <img
                  width="130px"
                  class="signInImg"
                  src="../assets/images/person3.png"
                  alt=""
                />
                <span class="signInAvatarTitle">Evan Mason</span>
                <!-- <h3>Managing director of school transport company</h3> -->
                <p class="signInQuote">
                  “Le consultant était professionnel et expérimenté, il a pu
                  répondre à toutes mes questions d'ordre fiscal, juridique et
                  de gestion d'entreprises,”
                </p>
                <!-- <p>Merci Digital Office</p> -->

              </div>
            </div>
          </div>
          <!-- <a
            class="carousel-control-prev"
            href="#carouselExampleIndicators"
            role="button"
            data-slide="prev"
          >
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a
            class="carousel-control-next"
            href="#carouselExampleIndicators"
            role="button"
            data-slide="next"
          >
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a> -->
          </div>
        </div>

        <div class="right">
          <div class="rightTop">
            
            <a href="signin.php">
              <button class="signInBtn" style="background: transparent !important;color: rgb(72, 71, 71);border: none;">You have already an account ?</button>
            </a>
            <a href="signin.php">
              <button class="signInBtn">Sign In Now</button>
            </a>
            <div style="position: relative;margin-left: 5px;">
              <select name="currency" style="width: 80px;" class="disable-arrow" id="currency">
                <option value="usd">$ USD</option>
                <option value="euro">€ EURO</option>
              </select>
              <span class="carets" style="position: absolute;top: 60%;right: 10px;transform: translateY(-50%);"></span>
            </div>
            <div class="signInLanguage dropdown">
              <button
                class="dropdown-toggle"
                type="button"
                id="dropdownMenuButton"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
                style="border: none"
              >
                <img
                  src="https://app.ecab.io/companyname/admin/public/english-flag.png"
                  alt=""
                  srcset=""
                />
                English
                <span class="carets"></span>
              </button>
              <div
                class="dropdown-menu"
                aria-labelledby="dropdownMenuButton"
              >
                <div class="lanOption">
                  <img
                    src="https://app.ecab.io/companyname/admin/public/french-flag.png"
                    alt=""
                    srcset=""
                    width="30px"
                  />
                  French
                </div>
                <div class="lanOption">
                  <img
                    src="https://app.ecab.io/companyname/admin/public/english-flag.png"
                    alt=""
                    srcset=""
                  />
                  
                  English
                </div>
              </div>
            </div>
          </div>
          <div class="rightMain signUp">
            <div class="wrapperRight">
                <div class="logoWrapper">
                  <img
                      class="signInLogo"
                      src="../assets/images/logo (1) (1).png"
                      alt=""
                      srcset=""
                  />
                </div>
              
              <form action="" class="signUpForm" id="signUpForm">
                <p class="welcome_text">Client Sign Up</p>
                <div class="register-heading">
                  <span>Informations personnelles</span>
                  <div class="divider"></div>
                </div>
                <div class="message">
                  <div class="send-success" id="sccess">
                    <img class="msgIcon" src="../assets/images/doneIcon.png" alt="" srcset=""> 
                    We have received your request, we will get back to you as soon as possible
                  </div>
                </div>
                <div class="message">
                  <div class="send-error" id="error">
                    <img class="msgIcon" src="../assets/images/dangerIcon.png" alt="" srcset=""> Please fill in all the required fields.
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-user"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="firstName"
                        required=""
                        id="firstName"
                        placeholder="First Name"
                      />
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-user"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="lastName"
                        required=""
                        id="lastName"
                        placeholder="Last Name"
                      />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-envelope"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="email"
                        id="email"
                        style="color: #000;font-size: 16px;padding-left: 20px;"
                        name="email"
                        required=""
                        placeholder="Your Email"
                      />
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-phone"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="phone"
                        id="phone"
                        placeholder="Phone"
                      />
                    </div>
                  </div>
                </div>
                <div class="register-heading">
                  <span>Adresse de facturation</span>
                  <div class="divider"></div>
                </div>
                <div class="row">
                  <div class="col-sm-6 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa-solid fa-location-dot"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        id="company"
                        style="color: #000"
                        name="company"
                        placeholder="Company"
                      />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa-solid fa-location-dot"></i
                          ></span>
                      <input
                        class="form-control adresse2"
                        type="text"
                        id="adresse2"
                        style="color: #000"
                        name="adresse"
                        required
                        placeholder="Address"
                      />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa-solid fa-location-dot"></i
                          ></span>
                      <input
                        class="form-control adresse2"
                        type="text"
                        id="adresse2"
                        style="color: #000"
                        name="adresse2"
                        required
                        placeholder="Address 2"
                      />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-4 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa-solid fa-location-dot"></i
                          ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="country"
                        id="country"
                        required=""
                        placeholder="Zip Code"
                      />
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa-solid fa-location-dot"></i
                          ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="region"
                        required=""
                        id="region"
                        placeholder="City"
                      />
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa-solid fa-location-dot"></i
                          ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="region"
                        required=""
                        id="region"
                        placeholder="Country"
                      />
                    </div>
                  </div>
                  <!-- <div class="col-sm-4">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-user"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="city"
                        required
                        id="city"
                        placeholder="City"
                      />
                    </div>
                  </div> -->
                </div>
                <!-- <div class="row">
                  <div class="col-sm-6 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-user"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="postal_code"
                        id="postal_code"
                        required=""
                        placeholder="Postal Code"
                      />
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-user"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="numero"
                        required=""
                        id="numero"
                        placeholder="Numero VAT"
                      />
                    </div>
                  </div>
                </div> -->
                <div class="register-heading">
                  <span>Sécurité du compte</span>
                  <div class="divider"></div>
                </div>
                <!-- <span class="register-heading"></span> -->

                <div class="row">
                  <div class="col-sm-6 form-group">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-lock"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="mot"
                        id="password"
                        required=""
                        placeholder="Password"
                      />
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div
                      class="input-group signupResBtnPopup2"
                      style="width: 100%; float: left; margin-right: 5px"
                    >
                      <span class="input-group-addon"
                        ><i class="fa fa-lock"></i
                      ></span>
                      <input
                        class="form-control c_civility"
                        type="text"
                        style="color: #000"
                        name="confermer"
                        required=""
                        id="confirm"
                        placeholder="Confirm Password"
                      />
                    </div>
                  </div>
                </div>

                <div class="row" style="margin-top: 10px;">
                  <div class="col-sm-12">
                    <button class="SignInBtn">Sign Up</button>
                  </div>
                </div>
                <!-- <div class="info_box">
                  <p class="info_text_top">
                    Joignez-vous à notre liste d'envoi
                  </p>
                  <p class="info_text_bottom">
                    We would like to send you occasional news, information and
                    special offers by email. To join our mailing list, simply
                    tick the box below. You can unsubscribe at any time
                  </p>
                  <div class="switchButtons">
                    <button class="switch_btn switch_btn_on on active ">On</button>
                    <button class="switch_btn switch_btn_off off">Off</button>
                  </div>
                </div> -->
                <!-- <button class="formSignInBtn">Sign Up</button> -->

                <!-- <div
                  class="col-lg-12 col-md-12 col-12"
                  style="
                    padding: 20px;
                    background-color: #fff;
                    margin-top: 10px;
                  "
                >
                  <div class="card">
                    <div class="card-body d-flex justify-content-center">
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckIndeterminate"
                          checked=""
                        />
                        <label
                          class="form-check-label" style="margin-left: 20px;margin-bottom: 10px;"
                          for="flexCheckIndeterminate"
                        >
                          J'ai lu et j'accepte les
                          <a href="" class="text-blue text-decoration-none">
                            Conditions d'utilisation</a
                          >
                        </label>
                      </div>
                    </div>
                  </div>
                </div> -->
                <div class="formRow" style="margin-top: 10px">
                </div>
              </form>
              <!-- <p
                style="
                  text-align: center;
                  color: rgb(68, 68, 68);
                  font-size: 18px;
                  font-weight: bold;
                "
              >
                NOS PARTENARIES ET NOS CLIENTS
              </p> -->

              
            </div>
          </div>
        </div>
      </div>
    </main>
    <script>
      // sigin form handling
      const fname = document.querySelector('#firstName');
  const lname = document.querySelector('#lastName');
  const email = document.querySelector('#email');
  const phone = document.querySelector('#phone');
  const address = document.querySelector('#adresse');
  const address2 = document.querySelector('#adresse2');
  const country = document.querySelector('#country');

  const region = document.querySelector('#region');
  const password = document.querySelector('#password');
  const confirme = document.querySelector('#confirm');




console.log(email,password)

  const submit_btn = document.querySelector('.formSignInBtn');
  
  submit_btn.addEventListener('click',(e)=>{
    // e.preventDefault();
    if(fname.value && lname.value && email.value && phone.value && address.value && address2.value && country.value && region.value && password.value && confirme.value ) {
      console.log(document.querySelector('#sccess'))
      document.querySelector('#error').style.display = 'none';

      document.querySelector('#sccess').style.display = 'block';
    }else{
      console.log(document.querySelector('#error'))
      document.querySelector('#sccess').style.display = 'none';

      document.querySelector('#error').style.display = 'block';
    }
  })

    </script>

    <script
      src="https://code.jquery.com/jquery-3.6.0.js"
      integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
      crossorigin="anonymous"
    ></script>
    <script
      src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
      integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
      integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
      integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
      crossorigin="anonymous"
    ></script>
    <script>
      var base_href = "/";
    </script>
    <script type="text/javascript" src="./js/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

    <script type="text/javascript" src="../assets/js/plugins.min.js"></script>

    <script src="../assets/js/map-style.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCTRSHf8sjMCfK9PHPJxjJkwrCIo5asIzE"></script>
    <script type="text/javascript" src="../assets/js/scripts.js"></script>
    <script src="../assets/js/authScript.js"></script>

    <!-- <script src="assets/js/legal.js"></script> -->
    

    <script>
      (function (i, s, o, g, r, a, m) {
        i["GoogleAnalyticsObject"] = r;
        (i[r] =
          i[r] ||
          function () {
            (i[r].q = i[r].q || []).push(arguments);
          }),
          (i[r].l = 1 * new Date());
        (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m);
      })(
        window,
        document,
        "script",
        "https://www.google-analytics.com/analytics.js",
        "ga"
      );

      ga("create", "UA-91006724-1", "auto");
      ga("send", "pageview");
    </script>
  </body>
</html>
